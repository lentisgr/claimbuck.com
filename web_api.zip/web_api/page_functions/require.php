<?php
require_once(realpath(dirname(__FILE__) . '/../../vendor/autoload.php'));