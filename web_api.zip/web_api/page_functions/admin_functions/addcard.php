<?php
use Defuse\Crypto\Crypto;
use Defuse\Crypto\Key;


function addCard($type,$value,$points,$code,$expdate) {
    $code = Crypto::encrypt($code, loadKey("./keyfile.txt"));
    echo $code;
    $query = QB::table('giftcards')->where('code', '=', $code);
    if($query->count()==0) {
        $data = array(
            'type' => $type,
            'value' => $value,
            'points' => $points,
            'code' => $code,
            'expdate' => $expdate
        );
        QB::table('giftcards')->insert($data);
        $json = array('succeed'=>'true','message'=>'INSERTED');
    } else {
        $json = array('succeed'=>'false','message'=>'ALREADY EXISTS');
    }
return json_encode($json,JSON_FORCE_OBJECT);
}
